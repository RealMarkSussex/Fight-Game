﻿namespace FightGame
{
    public class Werewolf : BaseClass
    {
        public bool Transformed { get; set; }

    }
}
