﻿namespace FightGame
{
    public class Player : BaseClass
    {

    }
}
