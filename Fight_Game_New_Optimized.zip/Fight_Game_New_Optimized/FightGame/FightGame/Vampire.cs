﻿namespace FightGame
{
    public class Vampire : BaseClass
    {
        public bool Psychic { get; set; }
        public bool Hybrid { get; set; }

    }
}
