﻿namespace FightGame
{
    public class Ghost : BaseClass
    {
        public bool Angry { get; set; }

    }
}
